# Telegram Bot - Docker Deployment

Telegram бот для поиска информации в Excel и мониторинга IP-адресов.

## 🚀 Быстрый старт

### Требования

- Docker и Docker Compose (или только Docker)
- Файл `.env` с настройками бота

### Установка и запуск

1. **Создайте файл `.env`** в корне проекта:

```env
# Обязательные параметры
TOKEN=your_telegram_bot_token
SUPERCHAT_TOKEN=your_chat_id

# ID топиков (тем в форуме)
EXCEL_TOPIC_ID=38
PING_TOPIC_ID=40
BOT_TOPIC_ID=42

# Пароль для Excel файла
EXCEL_PASSWORD=your_password

# Пути к файлам
EXCEL_FILE_PATH=\\fs\it$\6. Наша\1. Общая\3. Общая документация ИТ\ВсеПК.xlsx
IP_ADDRESSES_PATH=main/assets/ip_addresses.xml

# Сообщение при запуске
BOT_STARTUP_MESSAGE=🤖 Бот включился и готов к работе\!

# Разрешенные топики (через запятую)
ALLOWED_THREADS=38,40,42,164

# Опционально: настройки логирования
LOG_FILE=bot_log.log
LOG_LEVEL=INFO
```

2. **Соберите и запустите контейнер:**

```bash
# С помощью Docker Compose (рекомендуется)
docker-compose up -d

# Или с помощью Docker напрямую
docker build -t telegram-bot .
docker run -d --name telegram-bot --env-file .env telegram-bot
```

3. **Проверьте логи:**

```bash
# Docker Compose
docker-compose logs -f

# Docker
docker logs -f telegram-bot
```

## 📋 Команды управления

```bash
# Запуск
docker-compose up -d

# Остановка
docker-compose stop

# Перезапуск
docker-compose restart

# Просмотр логов
docker-compose logs -f

# Остановка и удаление
docker-compose down

# Пересборка образа
docker-compose build --no-cache
```

## 🐳 Docker на Windows Server 2019

### Установка Docker

1. **Скачайте Docker Desktop для Windows Server:**
   - https://docs.docker.com/desktop/install/windows-server/

2. **Или используйте Docker Engine:**
   ```powershell
   # Установка через Chocolatey
   choco install docker-desktop
   ```

3. **Проверьте установку:**
   ```powershell
   docker --version
   docker-compose --version
   ```

### Особенности для Windows Server

- Для доступа к сетевым дискам Windows (`\\fs\it$`) может потребоваться:
  - Использовать `network_mode: host` в docker-compose.yml
  - Или монтировать сетевой диск как volume
  - Или использовать SMB mount внутри контейнера

- Если Excel файл на сетевом диске, добавьте в `docker-compose.yml`:
  ```yaml
  volumes:
    - //fs/it$/6. Наша:/mnt/excel:ro
  ```

## 📁 Структура проекта

```
TelegramBot/
├── main/                    # Основной код бота
│   ├── assets/             # Конфигурация и ресурсы
│   ├── modules/             # Модули бота
│   │   ├── handlers/       # Обработчики команд
│   │   └── aiogram_bot.py  # Основной файл бота
│   ├── utils/              # Утилиты
│   └── main.py             # Точка входа
├── logs/                    # Логи (создается автоматически)
├── .env                     # Переменные окружения (не в git!)
├── Dockerfile              # Docker образ
├── docker-compose.yml      # Docker Compose конфигурация
├── requirements.txt        # Зависимости для Windows
└── requirements-docker.txt  # Зависимости для Docker
```

## ⚙️ Конфигурация

### Переменные окружения

| Переменная | Описание | Обязательная | По умолчанию |
|-----------|----------|--------------|--------------|
| `TOKEN` | Токен Telegram бота | ✅ Да | - |
| `SUPERCHAT_TOKEN` | ID чата (отрицательное число) | ✅ Да | - |
| `EXCEL_TOPIC_ID` | ID топика для Excel поиска | Нет | 38 |
| `PING_TOPIC_ID` | ID топика для мониторинга | Нет | 40 |
| `BOT_TOPIC_ID` | ID топика для команд бота | Нет | 42 |
| `EXCEL_PASSWORD` | Пароль Excel файла | Нет | - |
| `EXCEL_FILE_PATH` | Путь к Excel файлу | Нет | `\\fs\it$...` |
| `IP_ADDRESSES_PATH` | Путь к XML с IP-адресами | Нет | `main/assets/ip_addresses.xml` |
| `BOT_STARTUP_MESSAGE` | Сообщение при запуске | Нет | `🤖 Бот включился...` |
| `ALLOWED_THREADS` | Разрешенные топики (через запятую) | Нет | `38,40,42,164` |
| `LOG_FILE` | Файл логов | Нет | `bot_log.log` |
| `LOG_LEVEL` | Уровень логирования | Нет | `DEBUG` |

## 🔧 Разработка

### Локальный запуск (без Docker)

```bash
# Установите зависимости
pip install -r requirements.txt

# Запустите бота
cd main
python main.py
```

### Запуск в Docker для разработки

```bash
# Сборка образа
docker build -t telegram-bot:dev .

# Запуск с монтированием кода
docker run -it --rm \
  --env-file .env \
  -v ${PWD}/main:/app/main \
  telegram-bot:dev
```

## 📝 Функционал бота

### Команды

- `/start` - Приветственное сообщение
- `/botexec` - Статус бота и время работы

### Поиск в Excel (топик ID: EXCEL_TOPIC_ID)

В топике для Excel бот автоматически обрабатывает текстовые сообщения:

- **По ФИО** - частичное совпадение
- **По телефону/IP** - точное совпадение
- **По рабочей станции** - начинается с `ws`

### Мониторинг IP (топик ID: PING_TOPIC_ID)

Автоматическая проверка доступности устройств из `ip_addresses.xml`.

## 🐛 Решение проблем

### Бот не запускается

1. Проверьте наличие `.env` файла
2. Убедитесь, что `TOKEN` и `SUPERCHAT_TOKEN` установлены
3. Проверьте логи: `docker-compose logs`

### Ошибки подключения к Telegram

- Проверьте интернет-соединение
- Убедитесь, что токен бота правильный
- Проверьте, не заблокирован ли доступ к api.telegram.org

### Проблемы с Excel файлом

- Убедитесь, что путь к файлу правильный
- Проверьте доступ к сетевому диску (если используется)
- Убедитесь, что пароль правильный

### Логи не пишутся

- Проверьте права доступа к директории `logs/`
- Убедитесь, что volume для логов смонтирован

## 📚 Дополнительная информация

- [Aiogram документация](https://docs.aiogram.dev/)
- [Docker документация](https://docs.docker.com/)
- [Python dotenv](https://pypi.org/project/python-dotenv/)

## 📄 Лицензия

Внутренний проект компании.

