# Полное описание проекта Telegram Bot (TBot)

## 📋 Общее описание

Telegram-бот для корпоративного использования, интегрированный с OTRS (Open-source Ticket Request System). Бот предоставляет функционал поиска информации в Excel файлах, мониторинга серверов по IP-адресам, интеграции с OTRS для работы с тикетами, авторизации пользователей через email-верификацию, а также веб-панель администратора для управления системой.

**Основные цели проекта:**
- Автоматизация поиска информации о сотрудниках в Excel базе данных
- Мониторинг доступности серверов и сетевых устройств
- Интеграция с OTRS для автоматической обработки заявок
- Централизованное управление через веб-панель
- Авторизация пользователей через корпоративную почту

---

## 🏗️ Архитектура проекта

### Технологический стек:

**Backend:**
- Python 3.9+
- Aiogram 3.x (Telegram Bot API framework)
- Flask (веб-панель администратора)
- SQLite (база данных)
- asyncio (асинхронная обработка)

**Основные библиотеки:**
- `aiogram` - фреймворк для Telegram ботов
- `aiohttp` - асинхронные HTTP запросы
- `openpyxl` - работа с Excel файлами
- `msoffcrypto-tool` - расшифровка защищённых Excel файлов
- `flask` + `flask-cors` - веб-панель
- `python-dotenv` - управление переменными окружения
- `bcrypt` - хэширование паролей
- `ldap3` - интеграция с Active Directory
- `beautifulsoup4` - парсинг HTML (legacy)

**Опциональные зависимости:**
- `pywin32` - для Windows-специфичных функций
- `nest_asyncio` - для вложенных event loops

### Структура проекта:

```
tbot/
├── main/                          # Основная директория приложения
│   ├── main.py                    # Точка входа приложения
│   ├── assets/
│   │   └── config.py             # Конфигурация (переменные окружения)
│   ├── modules/
│   │   ├── aiogram_bot.py        # Основной модуль Telegram бота
│   │   ├── web_admin.py          # Flask веб-панель администратора
│   │   └── handlers/             # Обработчики различных функций
│   │       ├── excel_handler.py  # Поиск в Excel файлах
│   │       ├── monitor_handler.py # Мониторинг серверов
│   │       ├── monitor_db.py     # База данных SQLite
│   │       ├── otrs_handler.py   # Интеграция с OTRS
│   │       ├── otrs_auth.py      # Авторизация пользователей OTRS
│   │       ├── mdaemon_handler.py # Интеграция с Active Directory
│   │       ├── ip_manager.py     # Управление IP-адресами
│   │       └── ping_handler.py   # Ping проверки (legacy)
│   ├── templates/                 # HTML шаблоны для веб-панели
│   │   ├── base.html
│   │   ├── login.html
│   │   ├── verify.html
│   │   ├── set_password.html
│   │   ├── dashboard.html
│   │   ├── servers.html
│   │   ├── ip_addresses.html
│   │   ├── metrics.html
│   │   ├── users.html
│   │   └── settings.html
│   ├── static/                    # Статические файлы (CSS, JS)
│   │   ├── css/style.css
│   │   └── js/
│   ├── utils/
│   │   ├── logger.py             # Настройка логирования
│   │   └── formatters.py         # Форматирование текста
│   ├── data/
│   │   └── monitor.db            # SQLite база данных (создаётся автоматически)
│   └── server/
│       └── Все ПК V2.0.xlsx      # Excel база данных сотрудников
├── requirements.txt               # Зависимости Python
├── Makefile                      # Команды управления (Windows PowerShell)
├── README.md                     # Документация
└── .env                          # Переменные окружения (не в git)
```

---

## 💾 База данных (SQLite)

База данных расположена в `main/data/monitor.db` и содержит следующие таблицы:

### 1. `servers` - Серверы для мониторинга
- `id` (INTEGER PRIMARY KEY)
- `name` (TEXT NOT NULL) - Имя сервера
- `ip` (TEXT NOT NULL) - IP-адрес
- `server_group` (TEXT NOT NULL) - Группа сервера
- `first_seen` (TIMESTAMP) - Когда впервые обнаружен
- `last_seen` (TIMESTAMP) - Последняя проверка
- UNIQUE(name, server_group)

### 2. `events` - События серверов (UP/DOWN)
- `id` (INTEGER PRIMARY KEY)
- `server_id` (INTEGER) - FK на servers
- `event_type` (TEXT) - 'UP' или 'DOWN'
- `event_time` (TIMESTAMP) - Время события
- `duration_seconds` (INTEGER) - Длительность недоступности

### 3. `metrics` - Агрегированные метрики серверов
- `id` (INTEGER PRIMARY KEY)
- `server_id` (INTEGER UNIQUE) - FK на servers
- `total_uptime_seconds` (INTEGER) - Общее время работы
- `total_downtime_seconds` (INTEGER) - Общее время простоя
- `downtime_count` (INTEGER) - Количество падений
- `longest_downtime_seconds` (INTEGER) - Самый долгий простой
- `last_status` (TEXT) - 'UP', 'DOWN', 'UNKNOWN'
- `last_status_change` (TIMESTAMP)

### 4. `daily_stats` - Дневная статистика
- `id` (INTEGER PRIMARY KEY)
- `server_id` (INTEGER) - FK на servers
- `date` (DATE) - Дата
- `uptime_seconds` (INTEGER)
- `downtime_seconds` (INTEGER)
- `downtime_count` (INTEGER)
- UNIQUE(server_id, date)

### 5. `persistent_messages` - Персистентные сообщения Telegram
- `id` (INTEGER PRIMARY KEY)
- `chat_id` (INTEGER)
- `topic_id` (INTEGER)
- `message_type` (TEXT) - 'dashboard', 'metrics', etc.
- `message_id` (INTEGER) - ID сообщения в Telegram
- `created_at` (TIMESTAMP)
- `updated_at` (TIMESTAMP)
- UNIQUE(chat_id, topic_id, message_type)

### 6. `pending_deletions` - Очередь удаления сообщений
- `id` (INTEGER PRIMARY KEY)
- `chat_id` (INTEGER)
- `topic_id` (INTEGER)
- `message_id` (INTEGER)
- `delete_after` (TIMESTAMP)
- `created_at` (TIMESTAMP)
- UNIQUE(chat_id, message_id)

### 7. `otrs_users` - Авторизованные пользователи OTRS
- `id` (INTEGER PRIMARY KEY)
- `telegram_id` (INTEGER UNIQUE) - ID пользователя в Telegram
- `telegram_username` (TEXT)
- `full_name` (TEXT) - Полное имя из Active Directory
- `otrs_email` (TEXT NOT NULL) - Email пользователя
- `otrs_username` (TEXT)
- `verified_at` (TIMESTAMP)
- `created_at` (TIMESTAMP)

### 8. `otrs_pending_verifications` - Коды верификации
- `id` (INTEGER PRIMARY KEY)
- `telegram_id` (INTEGER UNIQUE)
- `email` (TEXT NOT NULL)
- `code` (TEXT NOT NULL) - 6-значный код
- `expires_at` (TIMESTAMP)
- `created_at` (TIMESTAMP)

### 9. `otrs_ticket_messages` - Отправленные тикеты
- `id` (INTEGER PRIMARY KEY)
- `ticket_id` (INTEGER)
- `ticket_number` (TEXT)
- `message_id` (INTEGER)
- `chat_id` (INTEGER)
- `topic_id` (INTEGER)
- `ticket_state` (TEXT)
- `sent_at` (TIMESTAMP)
- `updated_at` (TIMESTAMP)
- UNIQUE(ticket_id, chat_id, topic_id)

### 10. `otrs_user_metrics` - Метрики действий пользователей
- `id` (INTEGER PRIMARY KEY)
- `telegram_id` (INTEGER)
- `telegram_username` (TEXT)
- `otrs_email` (TEXT)
- `action_type` (TEXT) - 'closed', 'rejected', 'assigned', 'commented'
- `ticket_id` (INTEGER)
- `ticket_number` (TEXT)
- `ticket_title` (TEXT)
- `action_time` (TIMESTAMP)
- `details` (TEXT)

### 11. `user_private_tickets` - Личные сообщения с тикетами
- `id` (INTEGER PRIMARY KEY)
- `telegram_id` (INTEGER)
- `ticket_id` (INTEGER)
- `ticket_number` (TEXT)
- `message_id` (INTEGER)
- `assigned_at` (TIMESTAMP)
- UNIQUE(telegram_id, ticket_id)

### 12. `web_users` - Пользователи веб-панели
- `email` (TEXT PRIMARY KEY)
- `password_hash` (TEXT) - Хэш пароля (bcrypt)
- `created_at` (TIMESTAMP)
- `last_login` (TIMESTAMP)
- `password_set_at` (TIMESTAMP)

### 13. `ad_users` - Пользователи из Active Directory (синхронизация)
- `email` (TEXT PRIMARY KEY)
- `full_name` (TEXT)
- `first_name` (TEXT)
- `last_name` (TEXT)
- `is_active` (INTEGER) - 0 или 1
- `synced_at` (TIMESTAMP)

---

## 🔧 Конфигурация

Все настройки хранятся в файле `.env` в корне проекта или в переменных окружения.

### Обязательные параметры:

```env
TOKEN=your_telegram_bot_token              # Токен бота от @BotFather
SUPERCHAT_TOKEN=-1001234567890            # ID чата (отрицательное число)
```

### Параметры топиков (Topic IDs):

```env
EXCEL_TOPIC_ID=38                          # Топик для поиска в Excel
PING_TOPIC_ID=40                           # Топик для мониторинга серверов
BOT_TOPIC_ID=42                            # Топик для команд бота
METRICS_TOPIC_ID=0                         # Топик для метрик (0 = отключено)
TASKS_TOPIC_ID=145                         # Топик для заявок OTRS
```

### Excel файл:

```env
EXCEL_FILE_PATH=\\fs\it$\6. Наша\1. Общая\3. Общая документация ИТ\ВсеПК.xlsx
EXCEL_PASSWORD=your_excel_password         # Пароль для Excel файла
```

### OTRS интеграция:

```env
OTRS_URL=https://otrs.company.ru           # URL OTRS сервера
OTRS_USERNAME=api_user                     # Логин для OTRS API
OTRS_PASSWORD=api_password                 # Пароль для OTRS API
OTRS_WEBSERVICE=TelegramBot                # Имя Web Service в OTRS
```

### SMTP (для отправки кодов верификации):

```env
SMTP_HOST=smtp.company.ru                  # SMTP сервер
SMTP_PORT=587                              # Порт (587 для TLS, 465 для SSL)
SMTP_USER=noreply@company.ru               # Email отправителя
SMTP_PASSWORD=smtp_password                # Пароль SMTP
SMTP_FROM_NAME=OTRS Bot                    # Имя отправителя
SMTP_USE_TLS=true                          # Использовать TLS (true/false)
```

### Active Directory:

```env
DOMAIN_SERVER=192.168.1.10                 # IP или FQDN контроллера домена
DOMAIN_PORT=389                            # Порт LDAP (389 или 636 для LDAPS)
DOMAIN_BASE_DN=dc=company,dc=local        # Base DN (автоопределяется если пусто)
DOMAIN_BIND_DN=                            # Bind DN (опционально)
DOMAIN_BIND_PASSWORD=                      # Пароль для Bind (опционально)
```

### Другие параметры:

```env
IP_ADDRESSES_PATH=main/assets/ip_addresses.xml  # Путь к XML (legacy, теперь используется БД)
BOT_STARTUP_MESSAGE=🤖 Бот включился и готов к работе\!
ALLOWED_THREADS=38,40,42,164               # Разрешённые топики (через запятую)
LOG_FILE=bot_log.log                       # Файл логов
LOG_LEVEL=INFO                             # Уровень логирования (DEBUG/INFO/WARNING/ERROR)
```

---

## 🤖 Функционал Telegram бота

### Команды бота:

#### `/start`
- Приветственное сообщение с кнопкой "Авторизоваться"
- Автоматическое удаление через 30 секунд
- Доступно только в личных сообщениях

#### `/botexec`
- Показывает статус бота
- Кнопка "Показать время работы" (uptime)
- Сообщение удаляется через 10 секунд после нажатия

#### `/status` (только в личных сообщениях)
- Показывает статус авторизации OTRS
- Информация о пользователе: email, ФИО, время авторизации

#### `/mystats`
- Личная статистика пользователя по OTRS
- Количество закрытых, отклонённых, назначенных заявок
- Последние действия

#### `/sync_mdaemon` (для администраторов)
- Синхронизация пользователей из Active Directory в БД
- Обновление таблицы `ad_users`

### Автоматическая обработка сообщений:

#### Поиск в Excel (топик ID: EXCEL_TOPIC_ID)

Бот автоматически обрабатывает текстовые сообщения в указанном топике:

**Типы поиска:**

1. **По ФИО** (частичное совпадение)
   - Примеры: "Иванов", "Петр", "Сергей Иванов"
   - Ищет в колонке "ФИО"

2. **По телефону или IP-адресу**
   - Примеры: "192.168.1.1", "2583109"
   - Автоматическое определение типа

3. **По рабочей станции (WS)**
   - Запрос должен начинаться с "ws" (регистр не важен)
   - Примеры: "ws111", "WS222"

**Формат ответа:**
- HTML таблица с колонками: ФИО, Подразделение, WorkStation, Телефон, AD, Примечание
- Если результатов много (>4000 символов), сообщение разбивается на части
- Сообщения автоматически удаляются через 5 минут

#### Мониторинг серверов (топик ID: PING_TOPIC_ID)

**Функционал:**
- Автоматическая проверка доступности серверов каждые 30 секунд
- Dashboard с live-обновлением статусов (одно персистентное сообщение)
- Уведомления при изменении статуса (UP → DOWN или DOWN → UP)
- Автоматическое удаление уведомлений через 30 секунд
- Метрики в отдельном топике (если METRICS_TOPIC_ID установлен)

**Источник данных:**
- Серверы загружаются из базы данных (таблица `servers`)
- Можно управлять через веб-панель (раздел "IP-адреса")

**Метрики:**
- Время работы (uptime)
- Время простоя (downtime)
- Количество падений
- SLA процент (доступность)
- Среднее время недоступности
- Самый долгий простой

#### Интеграция с OTRS (топик ID: TASKS_TOPIC_ID)

**Автоматическая обработка:**
- Проверка новых/обновлённых тикетов каждые 60 секунд
- Отправка уведомлений о новых тикетах
- Отправка уведомлений об изменениях (назначение, закрытие, отклонение)
- Дублирование уведомлений в личные сообщения авторизованных пользователей
- Защита от дублей при перезапуске бота

**Типы событий:**
- `closed` - тикет закрыт
- `rejected` - тикет отклонён
- `assigned` - тикет назначен
- `commented` - добавлен комментарий

**Авторизация пользователей OTRS:**

1. Пользователь отправляет `/start` в личные сообщения
2. Нажимает кнопку "Авторизоваться"
3. Вводит корпоративный email (разрешённые домены: meb52.com, tdegregor.ru, test.com)
4. Получает 6-значный код на почту
5. Вводит код в боте
6. Бот получает ФИО из Active Directory (если настроено)
7. Пользователь авторизован, может получать уведомления о тикетах

**Особенности:**
- Старые коды верификации автоматически удаляются при новом запросе
- Коды действительны 10 минут
- Можно изменить email во время ввода кода

---

## 🌐 Веб-панель администратора

Веб-панель доступна по адресу: `http://localhost:555`

### Авторизация:

**Первый вход:**
1. Ввод email (разрешённые домены: @meb52.com, @tdegregor.ru, @test.com)
2. Получение 6-значного кода на почту
3. Ввод кода
4. Предложение установить пароль для быстрого входа

**Последующие входы:**
- По умолчанию: вход по паролю
- Опция: "Войти по коду на почту"

**Безопасность:**
- Пароли хэшируются через bcrypt
- Минимальная длина пароля: 8 символов
- Сессия не истекает (100 лет, но можно выйти вручную)

### Страницы веб-панели:

#### 1. Dashboard (/dashboard)
- Общая статистика системы
- Количество онлайн/оффлайн серверов
- Количество тикетов за сегодня
- Количество активных пользователей
- Графики и визуализация

#### 2. Мониторинг серверов (/servers)
- Список всех серверов с текущим статусом
- Группировка по группам
- Фильтрация по статусу (online/offline)
- Информация о последней проверке

#### 3. Управление IP-адресами (/ip-addresses)
- CRUD операции для групп серверов
- CRUD операции для устройств в группах
- Валидация IP-адресов
- Данные сохраняются в БД (таблица `servers`)
- Синхронизация с мониторингом в реальном времени

#### 4. Метрики OTRS (/metrics)
- Статистика по пользователям
- Графики активности
- Последняя активность (таблица событий)
- Еженедельные отчёты

#### 5. Пользователи (/users)
- Список авторизованных пользователей OTRS
- Информация: Telegram ID, username, email, ФИО
- Время авторизации

#### 6. Настройки (/settings)
- Конфигурация системы
- Параметры интеграций

---

## 🔌 Интеграции

### 1. OTRS (Open-source Ticket Request System)

**Протокол:** REST API через GenericInterface

**Методы:**

- `TicketSearch` - поиск тикетов
- `TicketGet` - получение информации о тикете
- `TicketCreate` - создание нового тикета

**Конфигурация:**
- URL сервера OTRS
- Credentials для API
- Имя Web Service (по умолчанию "TelegramBot")

**Обработка событий:**
- Периодическая проверка (каждые 60 секунд)
- Отслеживание изменений состояния тикетов
- Фильтрация по очередям и состояниям

### 2. Active Directory (через LDAP)

**Протокол:** LDAP (порт 389) или LDAPS (порт 636)

**Функционал:**
- Автоматическое определение Base DN из rootDSE
- Поиск пользователей по email (`userPrincipalName`)
- Получение атрибутов: `mail`, `cn`, `displayName`, `givenName`, `sn`
- Синхронизация пользователей в БД (таблица `ad_users`)

**Конфигурация:**
- Адрес контроллера домена (IP или FQDN)
- Порт (389 для LDAP, 636 для LDAPS)
- Base DN (опционально, определяется автоматически)
- Bind DN и пароль (опционально, для анонимного подключения не требуется)

### 3. SMTP (отправка email)

**Протокол:** SMTP с поддержкой TLS/SSL

**Функционал:**
- Отправка кодов верификации
- HTML и plain text версии писем
- Красивое оформление писем

**Поддерживаемые режимы:**
- TLS (порт 587)
- SSL (порт 465)
- Plain (без шифрования)

---

## 🔄 Процессы и задачи

### Асинхронные задачи:

1. **Мониторинг серверов** (`monitor_handler.py`)
   - Периодичность: каждые 30 секунд
   - Ping проверка каждого сервера
   - Обновление dashboard сообщения
   - Отправка уведомлений при изменении статуса
   - Запись событий в БД

2. **Интеграция OTRS** (`otrs_handler.py`)
   - Периодичность: каждые 60 секунд
   - Поиск новых/изменённых тикетов
   - Отправка уведомлений в Telegram
   - Дублирование в личные сообщения пользователей
   - Запись метрик действий

3. **Удаление сообщений** (`aiogram_bot.py`)
   - Отложенное удаление через заданные интервалы
   - Управление через таблицу `pending_deletions`
   - Автоматическая очистка после удаления

### Веб-панель (Flask):

- Запускается в отдельном потоке
- Порт: 555
- Режим: development (debug=False в production)
- CORS: включён

---

## 📝 Логирование

**Система логирования:**
- Вывод в файл (`bot_log.log`) и консоль
- Форматирование с временем по MSK (UTC+3)
- Уровни: DEBUG, INFO, WARNING, ERROR, CRITICAL
- Ротация не настроена (логи накапливаются)

**Формат логов:**
```
YYYY-MM-DD HH:MM:SS [LEVEL] module_name: message
```

**Основные модули:**
- `modules.aiogram_bot` - основной бот
- `modules.web_admin` - веб-панель
- `modules.handlers.*` - обработчики
- `utils.logger` - система логирования

---

## 🚀 Развёртывание

### Локальный запуск (Windows):

```powershell
# 1. Установка зависимостей
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt

# 2. Настройка .env файла
# Создайте .env в корне проекта с необходимыми параметрами

# 3. Запуск бота
cd main
python main.py
```

### Использование Makefile:

```powershell
make install    # Установка зависимостей
make start      # Запуск в фоне
make stop       # Остановка
make restart    # Перезапуск
make status     # Проверка статуса
make logs       # Просмотр логов
make logs-follow # Следить за логами в реальном времени
make run        # Запуск в терминале (для отладки)
make clean      # Очистка кэша
```

### Windows Service (через BAS.py):

```powershell
python BAS.py install  # Установка как сервис
python BAS.py start    # Запуск сервиса
python BAS.py stop     # Остановка
python BAS.py remove   # Удаление сервиса
```

### Полная команда перезапуска:

```powershell
cd S:\Projects\tbot; Get-Process python -ErrorAction SilentlyContinue | Stop-Process -Force; Start-Sleep -Seconds 2; cd main; S:\Projects\tbot\.venv\Scripts\python.exe main.py
```

---

## 🔒 Безопасность

### Авторизация:

1. **Telegram бот:**
   - Авторизация через email-верификацию
   - Коды верификации: 6 цифр, действительны 10 минут
   - Проверка домена email (whitelist)
   - Очистка старых кодов при новом запросе

2. **Веб-панель:**
   - Первый вход: код на почту
   - Последующие входы: пароль (bcrypt)
   - Опция входа по коду
   - Сессии без истечения (но можно выйти)

### Хранение данных:

- Пароли: bcrypt хэши
- Коды верификации: в памяти (веб) или БД (Telegram)
- Токены: в переменных окружения (не в git)
- База данных: SQLite файл на диске

### Доступ:

- Веб-панель: только для пользователей с разрешёнными доменами
- Telegram бот: публичный, но функционал ограничен авторизацией
- База данных: файл SQLite, доступ через файловую систему

---

## 📊 Особенности реализации

### Обработка сообщений Telegram:

- **Parse Mode:** MarkdownV2 по умолчанию, HTML для таблиц
- **Escape специальных символов:** автоматическое экранирование для MarkdownV2
- **Удаление сообщений:** отложенное удаление через asyncio.create_task
- **Персистентные сообщения:** сохранение ID в БД для обновления после перезапуска

### Мониторинг серверов:

- **Ping проверка:** subprocess с ping командой
- **Таймаут:** 2 секунды по умолчанию
- **Интервал проверки:** 30 секунд
- **Персистентный dashboard:** одно сообщение с постоянным обновлением
- **Метрики:** отдельное сообщение в другом топике

### Работа с Excel:

- **Защищённые файлы:** расшифровка через msoffcrypto-tool
- **Чтение:** openpyxl в режиме read_only
- **Поиск:** итерация по строкам с фильтрацией
- **Форматирование:** HTML таблицы через tabulate

### База данных:

- **SQLite:** файловая БД, не требует сервера
- **Соединения:** создаются для каждого запроса (без connection pooling)
- **Миграции:** автоматические через ALTER TABLE с обработкой ошибок
- **Индексы:** на часто используемых полях (telegram_id, action_time)

---

## 🐛 Известные ограничения

1. **SQLite не поддерживает конкурентные записи:** при высокой нагрузке может быть bottleneck
2. **Память кодов верификации:** коды веб-панели хранятся в памяти, теряются при перезапуске
3. **Нет ротации логов:** файл `bot_log.log` растёт бесконечно
4. **Мониторинг не масштабируется:** один процесс проверяет все серверы последовательно
5. **Нет защиты от DDoS:** веб-панель не имеет rate limiting

---

## 🔮 Возможности для улучшения

1. **Кластеризация:**
   - Миграция на PostgreSQL для распределённой работы
   - Redis для координации между инстансами
   - Leader election для scheduled задач
   - Healthcheck и heartbeat механизмы

2. **Производительность:**
   - Connection pooling для БД
   - Кэширование результатов поиска в Excel
   - Параллельная проверка серверов (asyncio.gather)
   - Rate limiting для веб-панели

3. **Функционал:**
   - API для внешних систем
   - Webhooks для событий
   - Расширенная аналитика
   - Экспорт отчётов

4. **Безопасность:**
   - JWT токены для веб-панели
   - Ротация логов
   - Audit log всех действий
   - Двухфакторная аутентификация

---

## 📚 Дополнительная информация

**Часовой пояс:** MSK (UTC+3) - используется везде в проекте

**Кодировка:** UTF-8 для всех файлов и сообщений

**Поддержка платформ:**
- Windows (основная)
- Linux/Docker (частично, через Dockerfile)

**Версия Python:** 3.9+

**Лицензия:** Внутренний проект компании

---

## 🎯 Основные сценарии использования

1. **Поиск информации о сотруднике:**
   - Пользователь пишет в топик Excel имя или телефон
   - Бот возвращает HTML таблицу с информацией
   - Сообщение автоматически удаляется через 5 минут

2. **Мониторинг серверов:**
   - Бот проверяет серверы каждые 30 секунд
   - При падении сервера отправляется уведомление
   - Dashboard показывает текущий статус всех серверов

3. **Работа с тикетами OTRS:**
   - При создании/изменении тикета бот отправляет уведомление
   - Пользователь видит тикет в общем чате и в личных сообщениях
   - Метрики собираются для статистики

4. **Управление через веб-панель:**
   - Администратор входит по паролю
   - Добавляет/редактирует серверы для мониторинга
   - Просматривает статистику и метрики
   - Управляет пользователями

---

Это полное описание проекта Telegram Bot. Все детали, архитектура, конфигурация и функционал задокументированы для понимания и дальнейшей разработки.

